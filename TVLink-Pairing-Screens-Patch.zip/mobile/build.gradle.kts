plugins { id("com.android.application") }
android {
    namespace = "com.tvlink.mobile"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.tvlink.mobile"
        minSdk = 24
        targetSdk = 34
        versionCode = 50
        versionName = "0.5.37"
    }
}
