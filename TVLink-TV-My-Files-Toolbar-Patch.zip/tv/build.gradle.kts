plugins { id("com.android.application") }
android {
    namespace = "com.tvlink.ui"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.tvlink.tv"
        minSdk = 24
        targetSdk = 34
        versionCode = 48
        versionName = "0.5.40"
    }
}
