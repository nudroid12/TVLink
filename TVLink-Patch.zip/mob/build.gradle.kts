plugins { id("com.android.application") }
android {
    namespace = "com.tvlink.mob"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.tvlink.mob"
        minSdk = 23
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"
    }
}
