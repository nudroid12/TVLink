package com.tvlink.tv;

import android.content.SharedPreferences;
import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.GeneralSecurityException;
import java.util.UUID;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

final class LinkNetwork implements AutoCloseable {
    private static final int PORT = 47833;
    private static final String PREFIX = "TVLink1";
    private final DatagramSocket listener;
    private volatile boolean pairing;

    LinkNetwork(SharedPreferences settings) {
        DatagramSocket socket = null;
        try {
            socket = new DatagramSocket(null);
            socket.setReuseAddress(true);
            socket.bind(new InetSocketAddress(PORT));
        } catch (SocketException error) {
            if (socket != null) socket.close();
            socket = null;
        }
        listener = socket;
        if (listener != null) new Thread(() -> respond(settings), "TVLink discovery").start();
    }

    static String sign(String token, String operation, String nonce) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(token.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            byte[] proof = mac.doFinal((PREFIX + ":" + operation + ":" + nonce).getBytes(StandardCharsets.UTF_8));
            return android.util.Base64.encodeToString(proof, android.util.Base64.NO_WRAP);
        } catch (GeneralSecurityException error) {
            throw new IllegalStateException(error);
        }
    }

    void enablePairingDiscovery(boolean enabled) {
        pairing = enabled;
    }

    private void respond(SharedPreferences settings) {
        while (!listener.isClosed()) {
            try {
                DatagramPacket request = new DatagramPacket(new byte[128], 128);
                listener.receive(request);
                String message = decode(request);
                String prefix = "TVLinkPair1 ";
                if (pairing && message.startsWith(prefix)) {
                    String nonce = message.substring(prefix.length());
                    if (!nonce.matches("[0-9a-f-]{36}")) continue;
                    String name = settings.getString("device_name", android.os.Build.MODEL);
                    byte[] response = (message + " " + name).getBytes(StandardCharsets.UTF_8);
                    listener.send(new DatagramPacket(response, response.length, request.getSocketAddress()));
                    continue;
                }
                String[] parts = message.split(" ", 3);
                String token = settings.getString("link_token", "");
                if (token.isEmpty() || parts.length != 3 || !PREFIX.equals(parts[0])
                        || !matches(sign(token, "lookup-tv", parts[1]), parts[2])) continue;
                byte[] reply = sign(token, "found-tv", parts[1]).getBytes(StandardCharsets.UTF_8);
                listener.send(new DatagramPacket(reply, reply.length, request.getSocketAddress()));
            } catch (IOException ignored) {
                // The socket closes when the receiver stops.
            }
        }
    }

    static String resolve(String host, String token) throws IOException {
        try (TransferClient client = new TransferClient(host, "PING", token)) {
            client.confirm();
            return host;
        } catch (IOException original) {
            try {
                return find(token);
            } catch (IOException unavailable) {
                throw original;
            }
        }
    }

    private static String find(String token) throws IOException {
        String nonce = UUID.randomUUID().toString();
        byte[] request = (PREFIX + " " + nonce + " " + sign(token, "lookup-mobile", nonce)).getBytes(StandardCharsets.UTF_8);
        String expected = sign(token, "found-mobile", nonce);
        try (DatagramSocket socket = new DatagramSocket()) {
            socket.setBroadcast(true);
            socket.send(new DatagramPacket(request, request.length, InetAddress.getByName("255.255.255.255"), PORT));
            long deadline = android.os.SystemClock.elapsedRealtime() + 2000;
            while (android.os.SystemClock.elapsedRealtime() < deadline) {
                socket.setSoTimeout((int) Math.max(1, deadline - android.os.SystemClock.elapsedRealtime()));
                DatagramPacket reply = new DatagramPacket(new byte[128], 128);
                socket.receive(reply);
                if (matches(expected, decode(reply))) return reply.getAddress().getHostAddress();
            }
        }
        throw new IOException("Linked device not found on Wi-Fi");
    }

    private static String decode(DatagramPacket packet) {
        return new String(packet.getData(), packet.getOffset(), packet.getLength(), StandardCharsets.UTF_8);
    }

    static boolean matches(String expected, String actual) {
        return MessageDigest.isEqual(expected.getBytes(StandardCharsets.UTF_8), actual.getBytes(StandardCharsets.UTF_8));
    }

    @Override public void close() {
        if (listener != null) listener.close();
    }
}
